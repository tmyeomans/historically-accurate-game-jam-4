from __future__ import print_function

import renpy
renpy.update_path()

from renpy.uguu.uguu import *
